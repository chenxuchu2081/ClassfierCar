//
//  ViewController.swift
//  ClassfierCarApp
//
//  Created by CHEN Xuchu on 11/5/2019.
//  Copyright © 2019 CHEN Xuchu. All rights reserved.
//

import UIKit
import CoreML
import ImageIO
import Vision
import Parse

class ViewController: UIViewController, UIImagePickerControllerDelegate,
UINavigationControllerDelegate  {
    
    
    @IBOutlet var label : UILabel?
    @IBOutlet var imageView : UIImageView?
    @IBOutlet var priceLabel: UILabel?
    @IBOutlet var maintancePeriod : UILabel?
    @IBOutlet var powerLabel : UILabel?
    @IBOutlet var fuelLabel : UILabel?
    
    let picker = UIImagePickerController()
    
    lazy var classificationRequest: VNCoreMLRequest = {
        do{
            let model = try VNCoreMLModel(for: ClassifierCarModel().model)
            
            let request = VNCoreMLRequest(model: model, completionHandler: { [weak self] request, error in
                self?.processClassifications(for: request, error: error)
            })
            request.imageCropAndScaleOption = .centerCrop
            return request
        }catch{
            fatalError("Failed to load Vision ML model: \(error)")
        }
    }()
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        picker.delegate = self
        //findCarInformation()
    }
    
    
    
    
    
    func processClassifications(for request: VNRequest, error: Error?) {
        DispatchQueue.main.async {
            guard let results = request.results else {
                self.label?.text = "Unable to classify image.\n\(error!.localizedDescription)"
                return
            }
            // The `results` will always be `VNClassificationObservation`s, as specified by the Core ML model in this project.
            let classifications = results as! [VNClassificationObservation]
            if classifications.isEmpty{
                self.label?.text = "Nothing recognized !"
            }else{
                print(classifications.description)
                let topClassifications = classifications.prefix(1)
//                let descriptions = topClassifications.map{
//                    classification in
//                    return String(format: "(percentage of %.2f :)\n %@\n", classification.confidence * 100.0, classification.identifier)
//                }
                let descriptions = topClassifications.map{
                    classification in
                    return String(classification.identifier)
                }

               
                
                
                print("Classfication:/n" + descriptions.joined(separator: "\n"))
                var name = descriptions.joined(separator: "\n")
                self.findCarInformation(CarName: name)
                self.label?.text = descriptions.joined(separator: "\n")
            }
        }
    }
    
    func updateClassification(for image: UIImage){
        label?.text = "Classifying..."
        let orientation = CGImagePropertyOrientation(rawValue: UInt32(image.imageOrientation.rawValue))
        guard let cimage = CIImage(image: image) else {
            fatalError("Unable to create \(CIImage.self) from \(image).")
        }
        
        DispatchQueue.global(qos: .userInitiated).async {
            let handler = VNImageRequestHandler(ciImage: cimage, orientation: orientation!)
            do {
                try handler.perform([self.classificationRequest])
            } catch {
                /*
                 This handler catches general image processing errors. The `classificationRequest`'s
                 completion handler `processClassifications(_:error:)` catches errors specific
                 to processing that request.
                 */
                print("Failed to perform classification.\n\(error.localizedDescription)")
            }
        }
    }
    
    
    @IBAction func photofromLibrary(_ sender: UIBarButtonItem) {
        // Show options for camera or library
        guard UIImagePickerController.isSourceTypeAvailable(.camera) else {
            ChoosePhotoPicker(sourceType: .photoLibrary)
            return
        }
        
        let photoSourceChooseAlert = UIAlertController()
        let takePhoto = UIAlertAction(title: "Take Photo", style: .default) { [unowned self] _ in
            self.ChoosePhotoPicker(sourceType: .camera)
        }
        let choosePhoto = UIAlertAction(title: "Choose Photo", style: .default) { [unowned self] _ in
            self.ChoosePhotoPicker(sourceType: .photoLibrary)
        }
        
        photoSourceChooseAlert.addAction(takePhoto)
        photoSourceChooseAlert.addAction(choosePhoto)
        photoSourceChooseAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        present(photoSourceChooseAlert, animated: true)
        
        //        picker.allowsEditing = false
        //        picker.sourceType = .photoLibrary
        //        picker.mediaTypes = UIImagePickerController.availableMediaTypes(for: .photoLibrary)!
        //        present(picker, animated: true, completion: nil)
    }
    
    func ChoosePhotoPicker(sourceType: UIImagePickerController.SourceType) {
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = sourceType
        present(picker, animated: true)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any])
    {
        let chosenImage = info[.originalImage] as! UIImage  //2
        imageView?.contentMode = .scaleAspectFit //3
        imageView?.image = chosenImage //4
        dismiss(animated:true, completion: nil) //5
        
        self.updateClassification(for: (self.imageView?.image)!)
    }
    
    //    @IBAction func takePhoto(_ sender: UIBarButtonItem) {
    //        picker.sourceType = .camera
    //        present(picker, animated: true, completion: nil)
    //    }
    
    //    @IBAction func loadAndPredict(btn: UIBarButtonItem){
    //        if btn.tag == 0{
    //            //let image = UIImage(named: "11746080_963537acdc.jpg")
    //            //self.imageView?.image = image
    //            self.updateClassification(for: (self.imageView?.image)!)
    //        }
    //    }
    
    func findCarInformation(CarName: String){
        
        var query = PFQuery(className:"Cars")
        
        query.whereKey("carName", equalTo:CarName)
        //query.order(byAscending: "carPrice")
        query.selectKeys(["carPrice"])
        query.selectKeys(["Power"])
        query.selectKeys(["Fuel"])
        query.selectKeys(["MaintenancePeriod"])
        query.findObjectsInBackground { (objects: [PFObject]?, error: Error?) in
            if let error = error {
                // Log details of the failure
                print(error.localizedDescription)
            } else if let objects = objects {
                // The find succeeded.
                print("Successfully retrieved \(objects.count) scores.")
                // Do something with the found objects
                for object in objects {
//                    print(object.objectId as Any)
//                     print("Successfully retrieved \(String(describing: object["carPrice"])) ");
//                    print("Successfully retrieved \(String(describing: object["MaintenancePeriod"])) ");
                    self.priceLabel?.text = "Price : \(object["carPrice"] as! String)"
                    self.maintancePeriod?.text = "Maintenance Period : \(object["MaintenancePeriod"] as! String)"
                    self.powerLabel?.text = "Power : \(object["Power"] as! String)"
                    self.fuelLabel?.text = "Fuel : \(object["Fuel"] as! String)"
                    
                }
            }
        }
        //find other objectID rembers
        
    
}

}
